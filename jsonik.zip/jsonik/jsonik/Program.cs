﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.IO;
using Newtonsoft.Json;

namespace jsonik
{
    internal class Program
    {
        public class Dane
        {
            public List<Oddzial> oddzialy { get; set; }
            public List<Nauczyciel> nauczyciele { get; set; }
            public List<Gabinet> gabinety { get; set; }
            Godzina godzina { get; set; }

            public Nauczyciel WyszukajNauczycielaPoId(string id)
            {
                var item = nauczyciele.Find(x => x.id == id);
                if (item == null)
                    throw new Exception();

                return item;
            }
        }

        public class Oddzial
        {
            public string nazwa { get; set; }
            public string plik { get; set; }
            public Oddzial(string nazwa, string plik)
            {
                this.nazwa = nazwa;
                this.plik = plik;
            }
        }

        public class Nauczyciel
        {
            public string nazwa { get; set; }
            public string plik { get; set; }
            public string id { get; set; }
        }

        public class Gabinet
        {
            public string nazwa { get; set; }
            public string plik { get; set; }
            public string opis { get; set; }
        }

        public class Godzina
        {
            public List<string> poczatek { get; set; }
            public List<string> koniec { get; set; }
        }

        public class Wychowawca : Nauczyciel
        {
            public Oddzial odzial { get; set; }
            public string przewodniczacy_klasy { get; set; }

            public Wychowawca(Oddzial odzial, string przewodniczacy_klasy, string nazwa, string plik, string id)
            {
                this.odzial = odzial;
                this.przewodniczacy_klasy = przewodniczacy_klasy;
                this.nazwa = nazwa;
                this.plik = plik;
                this.id = id;
            }
        }

        public static string Between(string STR, string FirstString, string LastString)
        {
            string FinalString;
            int Pos1 = STR.IndexOf(FirstString) + FirstString.Length;
            int Pos2 = STR.IndexOf(LastString);
            FinalString = STR.Substring(Pos1, Pos2 - Pos1);
            return FinalString;
        }

        public static List<string> WypiszPlanNauczyciela(dynamic planNauczyciela)
        {
            List<string> tab = new List<string>(new string[40]);

            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    if (planNauczyciela[j][i] == "&nbsp;")
                        tab[i * 5 + j] = "0";
                    else
                    {
                        tab[i * 5 + j] = Between((string)planNauczyciela[j][i], "tab-s\">", "</a><br>");
                    }
                }
            }
            return tab;
        }

        static void Main(string[] args)
        {
            string json = File.ReadAllText(@"C:\Users\5TP1\Desktop\C#\jsonik\jsonik\lista.json");

            Dane dane = JsonConvert.DeserializeObject<Dane>(json);

            foreach (var item in dane.nauczyciele)
            {
                Console.WriteLine("nazwa: {0}, plik: {1}, id: {2}", item.nazwa, item.plik, item.id);
            }

            Console.WriteLine();

            string ID = "MW";

            Console.WriteLine("Nauczyciel o id \"" + ID + "\": " + dane.WyszukajNauczycielaPoId(ID).nazwa);

            string jsonPlan = File.ReadAllText(@"C:\Users\5TP1\Desktop\C#\jsonik\jsonik\" + dane.WyszukajNauczycielaPoId(ID).plik + ".json");

            dynamic planNauczyciela = JsonConvert.DeserializeObject<dynamic>(jsonPlan);
            Console.WriteLine("Plan nauczyciela o ID: \"" + ID + "\":");

            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    Console.Write(WypiszPlanNauczyciela(planNauczyciela)[i * 5 + j] + " ");
                }
                Console.WriteLine("");
            }

            List<Wychowawca> wychowawcy = new List<Wychowawca>
            {
                new Wychowawca(new Oddzial("5TP", "o12"), "Marcin Grochalski", "Bartłomiej Dykta", "n12", "BD"),
                new Wychowawca(new Oddzial("4TP", "o13"), "Michał Sperczyński", "Dominik Kubica", "n13", "DK"),
                new Wychowawca(new Oddzial("3TP", "o14"), "Konrad Stajak", "Szymon Biliński", "n14", "SB"),
            };

            string serialized_json = JsonConvert.SerializeObject(wychowawcy);

            File.WriteAllText(@"C:\Users\5TP1\Desktop\C#\jsonik\jsonik\wychowawcy.json", serialized_json);

            Console.ReadLine();
        }
    }
}
